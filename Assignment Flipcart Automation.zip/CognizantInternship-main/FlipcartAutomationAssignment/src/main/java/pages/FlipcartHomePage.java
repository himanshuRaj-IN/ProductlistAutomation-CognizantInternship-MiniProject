package pages;



import java.util.List;
import java.util.Properties;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.Select;

import utilities.DriverSetup;
import utilities.ReadPropertiesFile;

public class FlipcartHomePage {

	public static WebDriver driver;
	public static WebElement webEle;

	public void driverSetup() {
		DriverSetup setupObj = new DriverSetup();
	driver = setupObj.driverSetup();
	}
	public void closeBrowser() {
		System.out.println("# Closing Browser.");	
		driver.quit();
	}

	public void openUrl(String urlNameInPropFile) {
		ReadPropertiesFile rpfObj = new ReadPropertiesFile();
		Properties prop = rpfObj.readPropertiesFile();
		System.out.println("$ Navigating to Url :  "+prop.getProperty(urlNameInPropFile)+".\n");
		driver.get(prop.getProperty(urlNameInPropFile));
	}
	
	public void closeLoginPopup() {
		System.out.println("$ Closing popup.\n");
		driver.findElement(By.className("_2doB4z")).click();
	}
	
	public void searchProduct(String searchItem) {
		System.out.printf("$ finding product for keyword  ' %s '\n",searchItem);
		driver.findElement(By.className("_3704LK")).sendKeys(searchItem);
		driver.findElement(By.className("_3704LK")).sendKeys(Keys.ENTER);
	}
	
	public void selectSearchSuggestion(String searchItem, String suggestionToClick) {
		System.out.printf("$ Selecting suggestion ' %s '\n",suggestionToClick);
		driver.findElement(By.className("_3704LK")).sendKeys(searchItem);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		List<WebElement> ele = driver.findElements(By.className("Y5N33s"));
		for (WebElement element : ele) {
			if(element.getText().contains(suggestionToClick)) {
				element.click();
				break;
			}
	}
		
		
	}
	
	public int searchResultPrice(int indexOfSearch) {
		List<WebElement> elments = driver.findElements(By.className("_30jeq3"));
		String price = elments.get(indexOfSearch).getText();
		price =price.substring(1);
		return Integer.parseInt(price.replaceAll(",", ""));
	}
	
	public void verifyPrice(short indexOfSearch, int amountToCompare) {
		System.out.printf("$ Validating price whether less than %d\n",amountToCompare);
		int price = searchResultPrice(indexOfSearch);
		if(price<amountToCompare) {
			System.out.println("PASS: Price is lesss than "+amountToCompare+"\n");
		}
		else {
			System.out.println("FAIL: Price is more than "+amountToCompare+"\n");
		}
	}

	public void verifyPrice(int price, int amountToCompare) {
		System.out.printf("$ Validating price whether less than %d\n",amountToCompare);

		if(price<amountToCompare) {
			System.out.println("PASS: Price is lesss than "+amountToCompare+"\n");
		}
		else {
			System.out.println("FAIL: Price is more than "+amountToCompare+"\n");
		}
	}

	public void selectOperatingSystem(String os) {
		System.out.printf("$ Selecting Operating System to %s \n",os);
		String xpathOs = String.format("//div[text()='%s']", os);
		driver.findElement(By.xpath("//div[text()='Operating System']")).click();
		driver.findElement(By.xpath(xpathOs)).click();
		
	}
	public void clickNewestFirst() {
		System.out.println("$ clicking on Newest First.");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//div[contains(text(),'Newest First')]")).click();
	}
	
	public String searchResultName(int indexOfSearch) {
		List<WebElement> elments = driver.findElements(By.className("_4rR01T"));
		String productName = elments.get(indexOfSearch).getText();
		return productName;
		
	}
	
	public String cickOnSearchResult(int indexOfSearch) {
		List<WebElement> elements = driver.findElements(By.className("_4rR01T"));
		elements.get(indexOfSearch).click();
		String productName = elements.get(indexOfSearch).getText();
		return productName;
		
	}
	
	
	public void displayResult(int noOfSearcheResult) {
		System.out.printf("$ Displaying First %d Search Results.\n",noOfSearcheResult);
		for (int i = 0; i < noOfSearcheResult; i++) {
			System.out.println("  Name   : "+searchResultName(i));
			System.out.println("  Price  : "+searchResultPrice(i));
		}
		System.out.println("");
	}
	
	public void setSlider(int price) {
		System.out.printf("$ Setting Slider to the %d\n",price);
		
		String priceStr= String.format("₹%d", price);
		Select selectObj = new Select(driver.findElements(By.className("_2YxCDZ")).get(1));
		selectObj.selectByVisibleText(priceStr);
	}

	public void cartTopLebel() {
		System.out.println("$ Verifying Cart lebel");
		String str = driver.findElement(By.xpath("//div[@ class = 'KK-o3G']")).getText();
		if(str.equalsIgnoreCase("3")) {
			System.out.println("PASS : "+str+" is on Cart Lebel");
		}
		else {
			System.out.println("FAIL : "+str+" is on Cart Lebel");
		}
		
	}
	
	public void navigateBack() {
		System.out.println("-- Navigating Back");
		driver.navigate().back();
	}
	public void clickOnFlipkart() {
		driver.findElement(By.xpath("//a/img[@ class = '_2xm1JU']")).click();
		
	}
	public void addToCart() {
		System.out.println("-- Adding Product to cart !!");
		for(String winHandle : driver.getWindowHandles()){
		   driver.switchTo().window(winHandle);
		}
//		driver.findElement(By.xpath("//button[text()='ADD TO CART']")).click();
		driver.findElement(By.cssSelector(".row .col > button")).click();
	}
}
