package testCases.FlipcartHomePage;

import pages.FlipcartHomePage;	

public class  VerifyCartCount extends FlipcartHomePage{
	
	public static void main(String[] args) {
		VerifyCartCount obj = new VerifyCartCount();
		try {
			
		obj.driverSetup();
		obj.openUrl("baseUrl");
		obj.closeLoginPopup();
		obj.searchProduct("mobiles");
		obj.cickOnSearchResult(0);
		obj.addToCart();
		obj.navigateBack();
		obj.cartTopLebel();
		obj.closeBrowser();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
	}



}
