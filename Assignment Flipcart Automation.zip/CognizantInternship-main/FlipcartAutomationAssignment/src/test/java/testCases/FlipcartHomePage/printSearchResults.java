package testCases.FlipcartHomePage;

import pages.FlipcartHomePage;

public class printSearchResults extends FlipcartHomePage {
	public static void main(String[] args) {
		printSearchResults obj = new printSearchResults();
		
		obj.driverSetup();
		obj.openUrl("baseUrl");
		obj.closeLoginPopup();
		obj.searchProduct("Mobiles");
		obj.displayResult(24); // 1-24(Max) are available on Flipkart Page 		
		obj.closeBrowser();
	}

}
