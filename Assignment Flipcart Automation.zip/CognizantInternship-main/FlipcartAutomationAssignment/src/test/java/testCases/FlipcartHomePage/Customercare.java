package testCases.FlipcartHomePage;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;

import pages.FlipcartHomePage;

public class Customercare extends FlipcartHomePage{
	public void hoveronMore() {
		System.out.println("$ Hovering over the more option");
		webEle = driver.findElement(By.xpath("//div[text()='More']"));
		Actions action = new Actions(driver);
		action.moveToElement(webEle).perform();
	}
	public void cickOnCustomerCare() {
		System.out.println("$ Clicking on the 24X7 Cutomer Care");
		Actions action = new Actions(driver);
		webEle = driver.findElement(By.xpath("//div[text()='24x7 Customer Care']"));
		action.moveToElement(webEle).click().perform();
		
	}
	public void verifyCustomerPage() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String str = driver.findElement(By.xpath("//h1")).getText();
		if(str.contains("24x7 Customer Care Support")) {
			System.out.println("PASS: sub heading is "+str);
		}
		else {
			System.out.println("FAIL: sub heading is "+str);
		}
		
	}
	public static void main(String[] args) {
		Customercare obj = new Customercare();
		obj.driverSetup();
		obj.openUrl("baseUrl");
		obj.closeLoginPopup();
		obj.hoveronMore();
		obj.cickOnCustomerCare();
		obj.verifyCustomerPage();
		obj.closeBrowser();
		
	}
	

}
